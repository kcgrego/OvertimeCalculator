﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC3_KCS_OvertimeCalculator
{
    public partial class OvertimeCalculatorForm : Form
    {
        public OvertimeCalculatorForm()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Preparation (data Dictionary)
            double hoursWorked;
            const double OVERTIME_HOURS = 40;
            const double MAX_HOURS = 168;
           string category;
            //Read from...
            hoursWorked = Convert.ToDouble(hoursWorkedTextBox);
            //if statement
            if (hoursWorked >= 0 && hoursWorked <= 40)
            {
                categoryLabel.Text = "Regular";
                categoryLabel.ForeColor = Color.Green;
            }
            {else if (hoursWorked > 40 && hoursWorked <= MAX_HOURS)
	{
                categoryLabel.Text = "Overtime";
	}
	}
                
            }
            //display 
            categoryLabel.Text = Convert.ToString(category);
            //focus
            hoursWorkedTextBox.Focus();
            //selectall
            hoursWorkedTextBox.SelectAll();
            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            hoursWorkedTextBox.Clear();
            categoryLabel.Text = "";
            hoursWorkedTextBox.Focus();

        }
    }
}
